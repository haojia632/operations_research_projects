# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 15:04:58 2017

@author: mquijada
"""
import csv
import sqlite3

conn = sqlite3.connect('dbNfl.db')
cursor = conn.cursor()
cursor.execute(''' DROP TABLE nflSchedule''')
cursor.execute('''CREATE TABLE nflSchedule (
away char (3),
home char (3),
dat char (10),
timeslot char (50),
quality numeric
)
''')


nflTeamReader = csv.reader(open('nfl_teams.csv', 'rU'))

awayGames = {}
for i in nflTeamReader:
    awatGames[i[2]] = #insert games 
    
weekdayNflReader = csv.reader(open('weekday_nfl.csv', 'rU'))